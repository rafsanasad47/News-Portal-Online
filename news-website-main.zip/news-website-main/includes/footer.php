     <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; 2021: <strong><a href="#">Ahmed | Creative Lab.</a></strong> All rights are reserved</p>
      </div>
 </footer>