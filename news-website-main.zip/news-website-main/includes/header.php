 <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-info fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php"><img src="images/logo2.png" height="50" width="150"></a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div>

  <style type="text/css">

    span{
       background-color: none;
       margin-left: 20px;
       padding: 5px 5px;
    }

  </style>
            <b><span id="date_time"></span></b>
            <script type="text/javascript">window.onload = date_time('date_time');</script>
</div>




        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="about-us.php" style="color: black; font-weight: 900">About</a>
            </li>
                 <li class="nav-item">
              <a class="nav-link" href="index.php" style="color: black; font-weight: 900">News</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="contact-us.php" style="color: black; font-weight: 900">Contact us</a>
            </li>
  
  
          </ul>
        </div>
      </div>
    </nav>