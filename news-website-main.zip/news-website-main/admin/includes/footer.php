
                <footer class="footer text-right">
                     <p class="m-0 text-center text-black">Copyright &copy; 2021: <strong><a href="#">Ahmed | Creative Lab.</a></strong> All rights are reserved</p>
                </footer>
